from django.shortcuts import render,redirect
from django.http import Http404,HttpResponse
from .models import Categorie,Article
from datetime import datetime
from .forms import ArticleForm,Rcherche

# Create your views here.
def home(request):
    return render(request,'api/base.html')

def create(request):
    if request.method=='POST':
        form=ArticleForm(request.POST)
        if form.is_valid():
            titre=form.cleaned_data['titre']
            contenu=form.cleaned_data['contenu']
            auteur=form.cleaned_data['auteur']
            categorie=form.cleaned_data['categorie']
            form.save()
            envoi=True

    else:
        form=ArticleForm()

    return render(request,'api/create.html',locals())            

def read(request):
    return render(request,'api/read.html',{'articles':Article.objects.all()})

def read_a(request,id):
    try:
        article=Article.objects.get(id=id)
    except Article.DoesNotExist:
        raise Http404
    return render(request,'api/read_a.html',locals())

def delete(request):
    return render(request,'api/delete.html',{'articles':Article.objects.all()})

def delete_a(request,id):
    Article.objects.get(id=id).delete()
    return redirect('delete')

def search(request):
    if request.method=='POST':
        form=Rcherche(request.POST)
        if form.is_valid():
            titre=form.cleaned_data['titre']
            contenu=form.cleaned_data['contenu']
            if True != (bool(titre) or bool(contenu)):
                return HttpResponse("<p> vous n'avez rien remplit</p>")
            articles_t=Article.objects.filter(titre__icontains=titre)
            articles_c=Article.objects.filter(contenu__icontains=contenu)

    else:
        form=Rcherche()        
    return render(request,'api/search.html',locals())

    
    