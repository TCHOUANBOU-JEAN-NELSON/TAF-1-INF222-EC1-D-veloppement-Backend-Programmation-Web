from django.db import models

# Create your models here.


class Categorie(models.Model):
    nom=models.CharField(max_length=50)

    def __str__(self):
        return f'categorie {self.nom}'

class Article(models.Model):
    titre=models.CharField(max_length=50,unique=True)
    contenu=models.TextField()
    date=models.DateTimeField(auto_now_add=True,auto_now=False,verbose_name="date d'ajout")
    auteur=models.CharField(max_length=50)
    categorie=models.ForeignKey('Categorie',on_delete=models.SET_NULL,null=True,blank=True)
    
    def __str__(self):
        return f'article {self.titre} ecrit par {self.auteur}' 