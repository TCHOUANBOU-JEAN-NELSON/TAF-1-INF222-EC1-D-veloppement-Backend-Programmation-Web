from django import forms
from .models import Categorie,Article

class ArticleForm(forms.ModelForm):
    class Meta:
        model=Article
        fields=['titre','contenu','auteur','categorie']

class Rcherche(forms.Form):
    titre=forms.CharField(max_length=100,label="entrer le titre ou une partie du titre de l'article que vous souhaitez",required=False)
    contenu=forms.CharField(max_length=100,label="entrer le contenu ou une partie du contenu de l'article que vous souhaitez",required=False)